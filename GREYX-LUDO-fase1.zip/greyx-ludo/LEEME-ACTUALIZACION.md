# GREYX LUDO — Actualización (Fase 1: economía, regalos, inventario, likes)

## 1. Qué se hizo en esta entrega
| Área | Cambio | Archivo |
|---|---|---|
| Regalos diarios | **Un solo sistema**: el Worker. Se quitó el reclamo alterno por Firestore. Un toque en el regalo que brilla ya reclama (antes eran 2 toques). La animación empieza al tocar y el premio sale **solo cuando el servidor confirma**. Si se pierde la respuesta, se confirma leyendo la billetera real (nunca se paga dos veces). El día se calcula con la **hora del servidor** (UTC‑4), no con la del teléfono. | `greyx-daily.js` |
| Tienda | Espera máxima por intento 12 s (antes 20 s ×3 con pausas largas): ahora 12 s ×2. Se quitó el regalo duplicado que traía la tienda. | `greyx-shop.js` |
| Equipamiento | Equipar se ve al instante; al servidor va **una petición a la vez por categoría** y solo la última elección (evita que, con cambios rápidos, se guarde un objeto distinto al que ves). No deja equipar lo no comprado. | `greyx-shop.js` |
| Worker | Misma lógica que tenías desplegada + cada respuesta trae `serverTime` y el regalo trae `lastDay`. Sin comillas invertidas (copiar/pegar seguro). | `greyx-shop-worker.js` |
| Limpieza | Eliminado `greyx-economy.js` (comprobado: se cargaba después de la tienda, nunca interceptaba nada; además sus escrituras las rechazan tus reglas actuales). `greyx-reparaciones.js` queda solo como diagnóstico 🩺 (se quitó el reclamo secundario, el redirector de URLs y la «tienda sin Worker» que estaba apagada). Quitados 2 puntos `.` sueltos que se dibujaban en pantalla. | `index.html`, `greyx-reparaciones.js` |
| URL del Worker | Una sola, definida en `index.html` (`window.GX_SHOP_API`). Antes había 3 distintas parcheadas en caliente. **Usé `https://greyx-shop.greyx.workers.dev`** (la que respondía HTTP 200 en tu diagnóstico). | `index.html` |
| Likes | El like es **permanente**: no se retira ni se repite (cliente + reglas). | `greyx-mejoras.js`, `firestore.rules` |
| Reglas | Ver `firestore.rules` (2 cambios, marcados con «CAMBIO v2»). | `firestore.rules` |
| Android | El workflow solo copiaba `index.html` a `www/`: la app Android quedaba **sin ningún `greyx-*.js`**. Ahora copia scripts, CSS y `assets/`. | `.github/workflows/android.yml` |

## 2. Cómo publicar (en este orden)
1. **Cloudflare Worker**: Workers & Pages → `greyx-shop` → Edit code → pega todo `greyx-shop-worker.js` → Deploy. Las variables `FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, `FIREBASE_PRIVATE_KEY` ya las tienes; no cambian.
2. **GitHub Pages**: sube el contenido de este ZIP al repositorio (reemplaza archivos, borra `greyx-economy.js`) y haz commit. Espera a que termine el workflow `static.yml`. Recarga el juego con caché limpia (los scripts cambiaron de versión `?v=`).
3. **Reglas de Firebase** (al final): Firestore → Reglas → pega todo `firestore.rules` → Publicar.
   *Por qué al final:* las reglas nuevas ya no permiten reclamar el regalo desde el navegador. Una app/pestaña vieja (que aún use el reclamo directo) dejaría de poder reclamar hasta actualizarse.

No se toca ningún dato existente: no hay migraciones, no se reinicia nada. Billeteras, inventarios y equipamiento siguen igual.

## 3. Pruebas realizadas (`npm test`)
- **Worker (13 pruebas, Firestore simulado en memoria)**: compra correcta · compra repetida con el mismo `txId` no cobra dos veces · no se compra dos veces un objeto permanente · monedas insuficientes · precio manipulado rechazado · usuario baneado · sin sesión = 401 · equipar solo lo comprado / desequipar · regalo no se reclama dos veces el mismo día · racha 1→2→3 y reinicio al saltar un día · reinicio exacto a las 04:00 UTC (12:00 a. m. UTC‑4) · dos reclamos simultáneos acreditan una sola vez · los precios del Worker coinciden con el catálogo del juego.
- **Regalos (navegador real, Worker simulado con 0,9 s de demora)**: animación en <150 ms · sin premio antes de confirmar · doble toque = 1 sola petición · premio y saldo tras confirmar · queda en «VUELVE EN…» · usa hora del servidor.
- **Tienda (navegador real)**: botón pasa a «PROCESANDO…» al instante · «COMPRA EXITOSA» · 1 solo cobro · precio enviado = catálogo · saldo 9 000→7 000 · el objeto aparece en inventario · equipar inmediato · cambio rápido entre dos dados deja guardado el último.
- **Apariencias**: las 12 (4 dados, 4 fichas, 4 tableros) se aplican y se limpian (navegador real).
- **Carga completa del juego** en 390×844, 820×1180 y 1366×768: sin errores de JavaScript y sin desborde horizontal.

## 4. Lo que NO pude probar desde aquí (hazlo tras publicar)
- No tengo conexión a tu Firebase ni a tu Worker: el Firestore de las pruebas es simulado. La concurrencia real de Firestore (reintentos por `ABORTED`) no está probada aquí; el Worker ya la maneja con transacciones.
- Las reglas no se validaron con el emulador de Firebase. Partí de tu archivo y solo cambié: (a) se quitó el reclamo diario por navegador (`walletClaimOk` y sus funciones auxiliares), (b) `likes`: `delete` ahora `false` y `likeCounts` solo sube de 1 en 1. Compara con diff si quieres.
- Lista de verificación en el juego: comprar → ver saldo → inventario → equipar → entrar a partida (el tablero/ficha/dado se aplican por CSS) → cerrar y reabrir (se conserva) → reclamar regalo → intentar reclamar otra vez.

## 5. Riesgos que detecté y NO modifiqué (decide tú)
1. **Resultado de partidas lo reporta el cliente** (`matches/{uid}_{gameId}` con `place`). Las reglas limitan XP y tiempo, pero un tramposo podría declarar «1.er lugar» y cobrar 100 monedas ×10 partidas/día. Solución real = servidor de partida autoritativo. Las misiones diarias heredarían este límite.
2. `role()` devuelve `'owner'` si un documento `admins/{uid}` no tiene campo `role`. Revisa que todos tus admins lo tengan.
3. `ideaLikes`/`ideaLikeCounts` (likes de ideas, no de cuentas): el contador lo puede subir/bajar cualquiera. No lo toqué porque no es el like de cuentas.
4. `Ludo-Greyx-menu-mejorado.zip` (1,5 MB), `fondo-menu.png` y `photo-output.jpeg` en la raíz no están referenciados por el código; no los borré.

## 6. Pendiente (siguientes fases, NO incluido en este ZIP)
Misiones diarias con panel admin · eventos/anuncios · panel de administración ampliado · 21 idiomas (RTL, fuentes) · mejoras visuales del tablero y centrado de ventanas · entrada cinematográfica y animaciones · ampliación del catálogo con rarezas. Nada de esto está medio hecho en este ZIP: no hay interfaces sin función.
