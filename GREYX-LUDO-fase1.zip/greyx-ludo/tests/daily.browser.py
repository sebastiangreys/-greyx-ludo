from playwright.sync_api import sync_playwright
import json, sys
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={"width":390,"height":844})
    errs=[]; pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.set_content("<!doctype html><html><body><div class='g8-claim'>RECLAMAR</div></body></html>")
    pg.evaluate("""() => {
      window.calls = []; window.walletDoc = {coins:100, daily:{streak:0, lastDay:-99}};
      window.GX = { state:{user:{uid:'u1'}}, fb:{auth:{currentUser:{getIdToken: async()=>'tok'}}, db:{}},
        fsModule: async()=>({onSnapshot:()=>()=>{}, doc:()=>({})}), render(){} };
      const DAY=86400000, TZ=-4*3600000;
      window.fetch = async (url, init) => {
        const path = url.replace(/^.*\\/api/, ''); calls.push(path);
        const send = (o, st=200) => new Response(JSON.stringify(Object.assign({serverTime: Date.now()+5000}, o)), {status: st});
        if (path === '/wallet/sync') return send({ok:true, coins:walletDoc.coins, daily:walletDoc.daily});
        if (path === '/wallet/daily') {
          await new Promise(r => setTimeout(r, 900));                       // el servidor tarda 0,9 s
          const today = Math.floor((Date.now()+5000+TZ)/DAY);
          if (walletDoc.daily.lastDay === today) return send({ok:false, code:'already', message:'Ya reclamaste'}, 400);
          walletDoc.coins += 50; walletDoc.daily = {streak:1, lastDay:today};
          return send({ok:true, day:1, gained:50, coins:walletDoc.coins, lastDay:today});
        }
        return send({ok:false}, 404);
      };
    }""")
    pg.add_script_tag(path="greyx-daily.js")
    pg.wait_for_function("window.GXDaily"); pg.wait_for_timeout(1300)      # arranque + sync
    r = {}
    pg.evaluate("GXDaily.open()"); pg.wait_for_selector(".gd-day.cur", timeout=3000)
    r["abre_con_regalo_disponible"] = True
    pg.click(".gd-day.cur"); pg.click(".gd-day.cur", force=True)           # doble toque
    pg.wait_for_timeout(120)
    r["animacion_inmediata(<150ms)"] = pg.locator(".gd-day.shake").count() == 1
    r["sin_premio_antes_de_confirmar"] = pg.locator(".gd-rw").count() == 0
    pg.wait_for_selector(".gd-rw", timeout=4000)
    r["premio_tras_confirmacion"] = "+50" in pg.inner_text(".gd-rw")
    r["solo_UN_reclamo_enviado"] = pg.evaluate("calls.filter(c=>c==='/wallet/daily').length") == 1
    r["monedas_en_juego"] = pg.evaluate("GX.state.gold") == 150
    pg.click(".gd-rw button"); pg.wait_for_timeout(200)
    r["queda_marcado_reclamado"] = "VUELVE EN" in pg.inner_text(".gd-btn")
    # segundo intento el mismo día desde el menú
    pg.evaluate("GXDaily.close()"); pg.wait_for_timeout(300); pg.evaluate("GXDaily.open()"); pg.wait_for_timeout(300)
    r["hoy_ya_no_se_puede_reclamar"] = pg.locator(".gd-day.cur").count() == 0
    r["usa_hora_del_servidor"] = abs(pg.evaluate("window.GX_SERVER_OFFSET") - 5000) < 300
    print(json.dumps(r, ensure_ascii=False, indent=1)); print("errores:", errs)
    sys.exit(0 if all(r.values()) and not errs else 1)
