from playwright.sync_api import sync_playwright
import json, sys
SETUP = """() => {
  window.calls = []; window.DB = { 'wallet/u1': {coins: 9000, daily:{streak:0,lastDay:-99}}, 'shopInventory/u1/items/dice_gold': {qty:1,cat:'dice'}, 'shopInventory/u1/items/dice_crystal': {qty:1,cat:'dice'} };
  window.L = {};
  const snapDoc = p => ({ exists: () => p in DB, data: () => DB[p] });
  const snapCol = p => ({ forEach: fn => Object.keys(DB).filter(k => k.startsWith(p + '/')).forEach(k => fn({ id: k.slice(p.length + 1), data: () => DB[k] })) });
  window.emit = p => (L[p] || []).forEach(f => f.col ? f.fn(snapCol(p)) : f.fn(snapDoc(p)));
  const fs = { doc: (db, ...a) => ({ path: a.join('/') }), collection: (db, ...a) => ({ path: a.join('/'), col: true }),
    onSnapshot: (ref, fn) => { (L[ref.path] = L[ref.path] || []).push({ fn, col: !!ref.col }); setTimeout(() => ref.col ? fn(snapCol(ref.path)) : fn(snapDoc(ref.path)), 0); return () => {}; } };
  window.GX = { state: { user: { uid: 'u1' }, profile: { username: 'tester' } }, fb: { auth: { currentUser: { getIdToken: async () => 'tok' } }, db: {} }, fsModule: async () => fs, render() {}, xpLevelFromTotal: x => 1 };
  let delayEquip = [1200, 100];                                  // la 1.ª petición de equipar tarda mucho más que la 2.ª
  window.fetch = async (url, init) => {
    const path = url.replace(/^.*\\/api/, ''), body = JSON.parse(init.body || '{}'); calls.push({ path, body });
    const send = (o, st = 200) => new Response(JSON.stringify(Object.assign({ serverTime: Date.now() }, o)), { status: st });
    if (path === '/wallet/sync') return send({ ok: true, coins: DB['wallet/u1'].coins, daily: DB['wallet/u1'].daily });
    if (path === '/shop/buy') {
      await new Promise(r => setTimeout(r, 700));
      const price = { dice_obsidian: 2000 }[body.productId];
      if (DB['shopInventory/u1/items/' + body.productId]) return send({ ok: false, code: 'owned', message: 'Ya tienes este producto.' }, 400);
      if (DB['wallet/u1'].coins < price) return send({ ok: false, code: 'funds', message: 'No tienes suficientes monedas.' }, 400);
      DB['wallet/u1'].coins -= price; DB['shopInventory/u1/items/' + body.productId] = { qty: 1, cat: 'dice' };
      setTimeout(() => { emit('wallet/u1'); emit('shopInventory/u1/items'); }, 50);
      return send({ ok: true, productId: body.productId, coins: DB['wallet/u1'].coins, qty: 1 });
    }
    if (path === '/shop/equip') {
      await new Promise(r => setTimeout(r, delayEquip.shift() || 50));
      const eq = Object.assign({ dice: null, token: null, board: null }, DB['shopEquip/u1'] || {}); eq[body.category] = body.productId; DB['shopEquip/u1'] = eq;
      return send({ ok: true, equip: { dice: eq.dice, token: eq.token, board: eq.board } });
    }
    return send({ ok: false, code: 'x' }, 404);
  };
}"""
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page(viewport={"width": 390, "height": 844})
    errs = []; pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.set_content("<!doctype html><html><body><div class='board'></div></body></html>")
    pg.evaluate(SETUP)
    for f in ["greyx-shop-catalog.js", "greyx-shop-art.js", "greyx-shop-skins.js", "greyx-shop.js"]: pg.add_script_tag(path=f)
    pg.wait_for_function("window.GXShop"); pg.wait_for_timeout(1500)
    r = {}
    pg.evaluate("GXShop.openShop('dice')")
    pg.click("[data-s=pick][data-id=dice_obsidian]"); pg.click("[data-s=buy][data-id=dice_obsidian]")
    pg.wait_for_selector(".gs-md button:has-text('COMPRAR')"); pg.click(".gs-md button:has-text('COMPRAR')")
    pg.wait_for_timeout(100)
    r["boton_responde_al_instante (PROCESANDO…)"] = "PROCESANDO" in pg.inner_text("[data-s=buy], .gs-det .gs-btn")
    pg.wait_for_selector(".gs-ok", timeout=4000)
    r["confirmacion_clara_COMPRA_EXITOSA"] = "COMPRA EXITOSA" in pg.inner_text(".gs-ok")
    r["un_solo_cobro_enviado"] = len([c for c in pg.evaluate("calls") if c["path"] == "/shop/buy"]) == 1
    r["precio_enviado_coincide_catalogo"] = [c for c in pg.evaluate("calls") if c["path"] == "/shop/buy"][0]["body"]["price"] == 2000
    pg.wait_for_timeout(300)
    r["monedas_descontadas_9000_a_7000"] = pg.evaluate("DB['wallet/u1'].coins") == 7000 and "7,000" in pg.inner_text(".gs-coins")
    pg.click(".gs-ok [data-o=later]"); pg.evaluate("GXShop.openInventory('dice')"); pg.wait_for_timeout(200)
    r["objeto_aparece_en_inventario"] = pg.locator(".gs-inv:has-text('Dado Obsidiana')").count() == 1
    # cambio rápido de dado: oro (lenta) y luego cristal (rápida)
    pg.click(".gs-inv:has-text('Dado Dorado') [data-s=equip]"); pg.click(".gs-inv:has-text('Dado Cristal') [data-s=equip]")
    pg.wait_for_timeout(60)
    r["equipar_se_ve_al_instante"] = pg.evaluate("document.body.getAttribute('data-gx-dice')") == "dice_crystal"
    pg.wait_for_timeout(1600)
    r["cambio_rapido_gana_la_ultima_accion"] = pg.evaluate("document.body.getAttribute('data-gx-dice')") == "dice_crystal"
    r["servidor_guardo_el_ultimo"] = pg.evaluate("DB['shopEquip/u1'].dice") == "dice_crystal"
    # no se puede equipar lo no comprado desde el cliente
    n0 = len(pg.evaluate("calls")); pg.evaluate("(()=>{})()")
    r["sin_errores_de_pagina"] = not errs
    print(json.dumps(r, ensure_ascii=False, indent=1)); print("errores:", errs)
    sys.exit(0 if all(r.values()) else 1)
