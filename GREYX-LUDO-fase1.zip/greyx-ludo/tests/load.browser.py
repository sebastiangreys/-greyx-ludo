from playwright.sync_api import sync_playwright
import json, sys, pathlib
root = pathlib.Path(__file__).resolve().parent.parent
with sync_playwright() as p:
    b = p.chromium.launch()
    for name, vp in [("iPhone", {"width": 390, "height": 844}), ("Tablet", {"width": 820, "height": 1180}), ("PC", {"width": 1366, "height": 768})]:
        pg = b.new_page(viewport=vp); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)[:140]))
        pg.route("**/*", lambda r: r.abort() if r.request.url.startswith("http") else r.continue_())
        pg.goto("file://" + str(root / "index.html")); pg.wait_for_timeout(2500)
        info = pg.evaluate("""() => ({ shop: !!window.GXShop, daily: !!window.GXDaily, skins: !!window.GXSkins, diag: !!window.GXDiag, api: window.GX_SHOP_API, economy: !!window.GXEconomy,
          overflowX: document.documentElement.scrollWidth > innerWidth + 1, strayDot: [...document.body.childNodes].some(n => n.nodeType === 3 && n.textContent.trim() === '.') })""")
        print(name, json.dumps(info), "errores:", errs[:3]); pg.close()
    b.close()
