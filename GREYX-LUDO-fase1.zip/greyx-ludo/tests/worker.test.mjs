import assert from "node:assert/strict";
import { createRequire } from "node:module";
import fs from "node:fs";
const W = await import("../greyx-shop-worker.js");
const require = createRequire(import.meta.url);
global.window = global; require("../greyx-shop-catalog.js");
const CAT = global.GXShopCatalog;

function memStore(seed) {
  const db = new Map(Object.entries(seed || {}));
  return { db, async tx(paths, fn) {
    const d = {}; paths.forEach(p => { d[p] = db.has(p) ? structuredClone(db.get(p)) : null; });
    const out = await fn(d);
    for (const w of out.writes) {
      if (w.t === "create" && db.has(w.path)) throw Object.assign(new Error("exists"), { fs: "ALREADY_EXISTS" });
      if (w.t === "del") db.delete(w.path);
      else if (w.t === "patch") db.set(w.path, Object.assign({}, db.get(w.path), w.data));
      else db.set(w.path, structuredClone(w.data));
    }
    return out.result;
  } };
}
let T = 0, now = Date.UTC(2026, 10, 24, 15, 0, 0);
const call = async (store, path, body, uid = "u1", at = now) => {
  const r = await W.handle(new Request("https://x/api" + path, { method: "POST", headers: { Authorization: "Bearer t" }, body: JSON.stringify(body || {}) }), {}, store, { now: at, verify: async () => uid });
  return { status: r.status, j: await r.json() };
};
const t = async (name, fn) => { await fn(); T++; console.log("  ok -", name); };
const wallet = c => ({ coins: c, daily: { streak: 0, lastDay: -99 }, games: { day: -99, count: 0 } });
const tx = i => "tx" + String(i).padStart(18, "0");

console.log("Worker:");
await t("precios del Worker = precios del catálogo del juego", () => {
  for (const p of CAT.PRODUCTS) { assert.ok(W.PRODUCTS[p.id], p.id); assert.equal(W.PRODUCTS[p.id].price, p.price, p.id); assert.equal(W.PRODUCTS[p.id].cat, p.cat); assert.equal(!!W.PRODUCTS[p.id].perm, !!p.perm); }
  assert.equal(Object.keys(W.PRODUCTS).length, CAT.PRODUCTS.length);
  assert.deepEqual(W.DAILY, CAT.DAILY);
});
await t("compra correcta descuenta monedas y crea inventario", async () => {
  const s = memStore({ "wallet/u1": wallet(5000) });
  const r = await call(s, "/shop/buy", { productId: "dice_gold", txId: tx(1), price: 2500 });
  assert.equal(r.status, 200); assert.equal(r.j.coins, 2500);
  assert.equal(s.db.get("wallet/u1").coins, 2500);
  assert.equal(s.db.get("shopInventory/u1/items/dice_gold").qty, 1);
  assert.equal(s.db.get("purchases/" + tx(1)).status, "completed");
  assert.ok(r.j.serverTime > 0);
});
await t("compra repetida con el mismo txId NO cobra dos veces", async () => {
  const s = memStore({ "wallet/u1": wallet(5000) });
  await call(s, "/shop/buy", { productId: "dice_gold", txId: tx(2), price: 2500 });
  const r = await call(s, "/shop/buy", { productId: "dice_gold", txId: tx(2), price: 2500 });
  assert.equal(r.j.replay, true); assert.equal(s.db.get("wallet/u1").coins, 2500);
});
await t("no se puede comprar dos veces un objeto permanente (otro txId)", async () => {
  const s = memStore({ "wallet/u1": wallet(9000) });
  await call(s, "/shop/buy", { productId: "board_neon", txId: tx(3), price: 4000 });
  const r = await call(s, "/shop/buy", { productId: "board_neon", txId: tx(4), price: 4000 });
  assert.equal(r.j.code, "owned"); assert.equal(s.db.get("wallet/u1").coins, 5000);
});
await t("monedas insuficientes: rechaza sin cobrar", async () => {
  const s = memStore({ "wallet/u1": wallet(100) });
  const r = await call(s, "/shop/buy", { productId: "dice_gold", txId: tx(5), price: 2500 });
  assert.equal(r.j.code, "funds"); assert.equal(s.db.get("wallet/u1").coins, 100); assert.equal(s.db.has("shopInventory/u1/items/dice_gold"), false);
});
await t("precio manipulado desde el navegador: rechazado", async () => {
  const s = memStore({ "wallet/u1": wallet(9000) });
  const r = await call(s, "/shop/buy", { productId: "dice_gold", txId: tx(6), price: 1 });
  assert.equal(r.j.code, "price"); assert.equal(s.db.get("wallet/u1").coins, 9000);
});
await t("usuario baneado no puede comprar", async () => {
  const s = memStore({ "wallet/u1": wallet(9000), "bans/u1": { permanent: true } });
  assert.equal((await call(s, "/shop/buy", { productId: "dice_gold", txId: tx(7), price: 2500 })).j.code, "banned");
});
await t("sin sesión válida: 401", async () => {
  const s = memStore({});
  const r = await W.handle(new Request("https://x/api/shop/buy", { method: "POST", body: "{}" }), {}, s, { verify: async () => { throw new Error("x"); } });
  assert.equal(r.status, 401);
});
await t("no se puede equipar lo que no se compró; sí lo comprado; y desequipar", async () => {
  const s = memStore({ "wallet/u1": wallet(9000) });
  assert.equal((await call(s, "/shop/equip", { category: "dice", productId: "dice_gold" })).j.code, "notowned");
  await call(s, "/shop/buy", { productId: "dice_gold", txId: tx(8), price: 2500 });
  const e = await call(s, "/shop/equip", { category: "dice", productId: "dice_gold" });
  assert.equal(e.j.equip.dice, "dice_gold");
  assert.equal((await call(s, "/shop/equip", { category: "token", productId: "dice_gold" })).j.code, "noproduct");
  assert.equal((await call(s, "/shop/equip", { category: "dice", productId: null })).j.equip.dice, null);
});
await t("regalo diario: primera vez día 1, segunda vez el mismo día rechazada", async () => {
  const s = memStore({ "wallet/u1": wallet(0) });
  const a = await call(s, "/wallet/daily"); assert.equal(a.j.day, 1); assert.equal(a.j.gained, 50);
  const b = await call(s, "/wallet/daily"); assert.equal(b.j.code, "already"); assert.equal(s.db.get("wallet/u1").coins, 50);
});
await t("racha: días consecutivos suben; saltarse un día reinicia", async () => {
  const s = memStore({ "wallet/u1": wallet(0) }); const D = 86400000;
  const r1 = await call(s, "/wallet/daily", {}, "u1", now);
  const r2 = await call(s, "/wallet/daily", {}, "u1", now + D);
  const r3 = await call(s, "/wallet/daily", {}, "u1", now + 2 * D);
  assert.deepEqual([r1.j.day, r2.j.day, r3.j.day], [1, 2, 3]);
  assert.equal(r3.j.coins, 50 + 75 + 100);
  const r5 = await call(s, "/wallet/daily", {}, "u1", now + 5 * D);
  assert.equal(r5.j.day, 1);
});
await t("reinicio diario a las 12:00 a. m. UTC-4 (04:00 UTC), no por reloj del teléfono", async () => {
  const s = memStore({ "wallet/u1": wallet(0) });
  const before = Date.UTC(2026, 10, 24, 3, 59, 0), after = Date.UTC(2026, 10, 24, 4, 1, 0);
  await call(s, "/wallet/daily", {}, "u1", before);
  assert.equal((await call(s, "/wallet/daily", {}, "u1", before + 30000)).j.code, "already");
  assert.equal((await call(s, "/wallet/daily", {}, "u1", after)).j.day, 2);
});
await t("dos reclamos simultáneos del regalo: solo uno se acredita", async () => {
  const s = memStore({ "wallet/u1": wallet(0) });
  const rs = await Promise.all([call(s, "/wallet/daily"), call(s, "/wallet/daily")]);
  assert.equal(s.db.get("wallet/u1").coins, 50, "monedas=" + s.db.get("wallet/u1").coins + " " + JSON.stringify(rs.map(r => r.j.code || "ok")));
});
console.log("\n" + T + " pruebas del Worker OK");
