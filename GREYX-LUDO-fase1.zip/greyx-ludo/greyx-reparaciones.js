/* GREYX LUDO — DIAGNÓSTICO 🩺 (solo owner, o añade #diag al final de la dirección)
   v3: ya no intercepta tienda ni regalos (eso ahora lo hace únicamente greyx-shop.js / greyx-daily.js contra el Worker).
   Se eliminaron: el reclamo alterno por Firestore, el redireccionador de URL del Worker y la "tienda sin Worker". */
(() => {
  "use strict";
  if (window.__gxRep) return; window.__gxRep = true;
  const G = () => window.GX;
  const BASE = String(window.GX_SHOP_API || "https://greyx-shop.greyx.workers.dev").replace(/\/+$/, "");
  const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const timeout = (p, ms) => Promise.race([p, new Promise((_, r) => setTimeout(() => r(Object.assign(new Error("tiempo agotado"), { name: "Timeout" })), ms))]);
  const toast = (m, bad) => { const t = document.createElement("div"); t.className = "gd-toast" + (bad ? " bad" : ""); t.textContent = m; document.body.appendChild(t); setTimeout(() => t.remove(), 2800); };

  /* ===== D) Diagnóstico ===== */
  const logs = [];
  const push = (k, m) => { logs.push(new Date().toLocaleTimeString() + " " + k + ": " + String(m).slice(0, 300)); if (logs.length > 40) logs.shift(); };
  addEventListener("error", e => push("error", e.message));
  addEventListener("unhandledrejection", e => { const r = e.reason; push("promesa", (r && (r.code || r.message)) || r); });
  const ow = console.warn;
  console.warn = function () {
    try { push("aviso", Array.from(arguments).map(a => a && a.code ? a.code + " " + (a.message || "") : a && a.message ? a.message : String(a)).join(" ")); } catch (e) {}
    return ow.apply(console, arguments);
  };
  const st = document.createElement("style");
  st.textContent = `
.gxd-b{position:fixed;left:10px;bottom:calc(84px + env(safe-area-inset-bottom,0px));z-index:1000020;width:42px;height:42px;border-radius:50%;border:1px solid #6d5cffaa;background:#0d1030;color:#fff;font-size:1.1rem;opacity:.75}
.gxd{position:fixed;inset:0;z-index:1000021;overflow-y:auto;background:#05060ff2;color:#fff;font-family:Inter,system-ui,sans-serif;padding:calc(14px + env(safe-area-inset-top,0px)) 14px 30px}
.gxd-in{max-width:520px;margin:0 auto}.gxd h2{margin:0 0 4px}.gxd p{color:#9aa4d6;font-size:.8rem;margin:0 0 12px}
.gxd-r{padding:10px 12px;margin-bottom:8px;border-radius:12px;background:#ffffff0a;border:1px solid #ffffff14;font-size:.76rem;line-height:1.4;word-break:break-word;white-space:pre-wrap}
.gxd-r b{display:block}.gxd-r.ok{border-color:#22c55e77}.gxd-r.no{border-color:#ef444499;background:#ef444414}.gxd-r.wa{border-color:#fbbf2488}
.gxd button.a{width:100%;min-height:46px;margin:6px 0;border:0;border-radius:13px;font:900 .85rem Inter,system-ui,sans-serif;color:#fff;background:linear-gradient(135deg,#8b5cf6,#6d28d9)}
.gxd button.g{background:#ffffff12;border:1px solid #ffffff22}`;
  document.head.appendChild(st);
  const DAY = 86400000, TZ = -4 * 3600000;

  async function run(box) {
    const out = [];
    const draw = () => { box.querySelector(".res").innerHTML = out.map(o => `<div class="gxd-r ${o.st}"><b>${o.st === "ok" ? "✅" : o.st === "no" ? "❌" : "⚠️"} ${esc(o.n)}</b>${esc(o.d)}</div>`).join("") || "Midiendo…"; };
    const add = (st, n, d) => { out.push({ st, n, d }); draw(); };
    draw();
    const g = G(), u = g && g.state.user;
    add(navigator.onLine ? "ok" : "no", "Internet del dispositivo", navigator.onLine ? "Conectado." : "Sin conexión.");
    if (!u) return add("no", "Sesión", "No hay sesión iniciada.");
    add("ok", "Sesión", "UID " + u.uid);

    // Worker: /api/health debe responder {"ok":true,"time":...}. Si falla aquí, el Worker de la tienda NO está desplegado con este código.
    let healthy = false;
    try {
      const t0 = Date.now(), r = await timeout(fetch(BASE + "/api/health", { cache: "no-store" }), 10000), j = await r.json();
      healthy = !!j.ok;
      add("ok", j.local ? "Tienda en modo sin Worker" : "Worker de la tienda /api/health", j.local ? "Las compras las valida Firestore con tus reglas." : "Responde (HTTP " + r.status + ", " + (Date.now() - t0) + " ms).");
      try {
        const tr = await timeout(fetch("https://worldtimeapi.org/api/timezone/Etc/UTC", { cache: "no-store" }), 6000), tj = await tr.json();
        const skew = Math.round(tj.unixtime - Date.now() / 1000);
        add(Math.abs(skew) > 120 ? "no" : "ok", "Reloj del teléfono vs hora real", "Diferencia: " + skew + " s" + (Math.abs(skew) > 120 ? ". El reloj está mal: ponlo en «Automático» (Ajustes → General → Fecha y hora)." : ". Correcto."));
      } catch (e2) { add("wa", "Reloj del teléfono", "No se pudo comparar con la hora real."); }
    } catch (e) {
      add("no", "Worker de la tienda /api/health: NO RESPONDE", e.name + ": " + e.message + "\nEl Worker «greyx-shop» no está desplegado con el código de la tienda (o su nombre/subdominio es otro). Abre esta dirección en el navegador:\n" + BASE + "/api/health\nDebe mostrar {\"ok\":true,...}.");
    }
    if (healthy) {
      try {
        const tok = await g.fb.auth.currentUser.getIdToken(), t0 = performance.now();
        const r = await timeout(fetch(BASE + "/api/wallet/sync", { method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + tok }, body: "{}" }), 15000);
        const txt = (await r.text()).slice(0, 220);
        add(r.ok ? "ok" : "no", "Worker /api/wallet/sync (con tu sesión)", "HTTP " + r.status + " en " + Math.round(performance.now() - t0) + " ms · " + txt + (r.status === 500 ? "\nError interno: faltan o están mal los secretos FIREBASE_* del Worker." : r.status === 401 ? "\nEl Worker rechaza tu sesión: FIREBASE_PROJECT_ID incorrecto." : ""));
      } catch (e) { add("no", "Worker /api/wallet/sync", e.name + ": " + e.message); }
    }

    try {
      const fs = await g.fsModule(), db = g.fb.db;
      const w = await fs.getDoc(fs.doc(db, "wallet", u.uid));
      if (!w.exists()) add("wa", "Billetera", "No existe todavía.");
      else {
        const d = w.data(), today = Math.floor((Date.now() + TZ) / DAY), dl = d.daily || {};
        const next = dl.lastDay === today - 1 ? (dl.streak % 7) + 1 : 1;
        add("ok", "Billetera (datos reales)", JSON.stringify(d, (k, v) => v && v.toMillis ? v.toMillis() : v));
        add(dl.lastDay !== today ? "ok" : "wa", "Recompensa diaria", dl.lastDay !== today ? "Disponible: día " + next + " (hoy RD = " + today + ")." : "Ya reclamada hoy.");
      }
      const b = await fs.getDoc(fs.doc(db, "bans", u.uid));
      add(b.exists() ? "wa" : "ok", "Sanciones", b.exists() ? "Existe un registro: " + JSON.stringify(b.data(), (k, v) => v && v.toMillis ? v.toMillis() : v) : "Sin registro.");
    } catch (e) { add("no", "Firestore", e.code || e.message); }
    add(logs.length ? "wa" : "ok", "Últimos avisos del juego (" + logs.length + ")", logs.slice(-12).join("\n") || "Ninguno.");
    box.dataset.report = out.map(o => (o.st === "ok" ? "OK " : o.st === "no" ? "FALLO " : "AVISO ") + o.n + " — " + o.d).join("\n");
  }

  function open() {
    if (document.getElementById("gxd")) return;
    const box = document.createElement("div"); box.id = "gxd"; box.className = "gxd";
    box.innerHTML = `<div class="gxd-in"><h2>Diagnóstico</h2><p>Mide la conexión real con la tienda y Firebase. No modifica tus datos.</p>
      <button class="a" data-d="run" type="button">Ejecutar de nuevo</button><button class="a g" data-d="copy" type="button">Copiar informe</button><button class="a g" data-d="close" type="button">Cerrar</button><div class="res">Midiendo…</div></div>`;
    box.addEventListener("click", async e => {
      const b = e.target.closest("[data-d]"); if (!b) return;
      if (b.dataset.d === "close") box.remove();
      else if (b.dataset.d === "run") run(box);
      else if (b.dataset.d === "copy") { try { await navigator.clipboard.writeText(box.dataset.report || ""); b.textContent = "¡Copiado!"; } catch (er) { b.textContent = "No se pudo copiar"; } }
    });
    document.body.appendChild(box); run(box);
  }
  setInterval(() => {
    const g = G(); if (!g) return;
    const show = !!(g.state.isOwner || /#diag/.test(location.hash));
    let b = document.querySelector(".gxd-b");
    if (show && !b) { b = document.createElement("button"); b.className = "gxd-b"; b.type = "button"; b.textContent = "🩺"; b.setAttribute("aria-label", "Diagnóstico"); b.onclick = open; document.body.appendChild(b); }
    else if (!show && b) b.remove();
  }, 1500);
  window.GXDiag = { open };
})();
